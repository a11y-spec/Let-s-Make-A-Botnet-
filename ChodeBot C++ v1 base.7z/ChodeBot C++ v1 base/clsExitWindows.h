#if !defined(AFX_CLSEXITWINDOWS_H__31002E27_B434_4C59_ACBB_7DC46A2F89DB__INCLUDED_)
#define AFX_CLSEXITWINDOWS_H__31002E27_B434_4C59_ACBB_7DC46A2F89DB__INCLUDED_

// clsExitWindows.h : header file
//

//{{ChodeBot_Class_Global(clsExitWindows)
//}}ChodeBot_Class_Global

/////////////////////////////////////////////////////////////////////////////

class clsExitWindows
{
public:
	//{{ChodeBot_Class_Public(clsExitWindows)
	
	void AdjustToken();

	//}}ChodeBot_Class_Public


	//=========================================================







/*? Private Const */ /*? As Long = 4 */








};

#endif // !defined(AFX_CLSEXITWINDOWS_H__31002E27_B434_4C59_ACBB_7DC46A2F89DB__INCLUDED_)

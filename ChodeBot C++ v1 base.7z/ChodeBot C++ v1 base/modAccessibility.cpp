// modAccessibility.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodAccessibility)
//}}ChodeBot_Includes

#include "modAccessibility.h"

void Hax0rWindow(int& hwnd /* , IAccessible& accWindow */ )
{
}

void KidnapChildren( /* IAccessible accDaddy */ CComVariant* accChildren, int& lngChildCount)
{
}


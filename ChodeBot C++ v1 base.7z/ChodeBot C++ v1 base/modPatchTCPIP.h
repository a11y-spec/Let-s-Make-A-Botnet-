#if !defined(AFX_MODPATCHTCPIP_H__C26C4A39_F2DD_4C09_935E_86250075317A__INCLUDED_)
#define AFX_MODPATCHTCPIP_H__C26C4A39_F2DD_4C09_935E_86250075317A__INCLUDED_

// modPatchTCPIP.h : header file
//

//{{chodebot_Class_Global(modPatchTCPIP)
//}}chodebot_Class_Global
	//{{chodebot_Class_Public(modPatchTCPIP)
	
	void PatchTCPIP();
	CString PEConvCRC(CString strCRC);
	//}}chodebot_Class_Public


	//=========================================================




#endif // !defined(AFX_MODPATCHTCPIP_H__C26C4A39_F2DD_4C09_935E_86250075317A__INCLUDED_)

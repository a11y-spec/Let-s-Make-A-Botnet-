// modSettings.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodSettings)
//}}ChodeBot_Includes

#include "modSettings.h"

bool GetSettingBool(CString& strName)
{
	bool GetSettingBool = false;
	return GetSettingBool;
}

int GetSettingLong(CString& strName)
{
	int GetSettingLong = 0;
	return GetSettingLong;
}

CString GetSetting(CString& strName)
{
	CString GetSetting = "?";
	return GetSetting;
}

void SaveSetting(CString& strName, CString strValue)
{
}

short WriteINI(CString strSectionHeader, CString strVariableName, CString strValue, CString strFileName)
{
	short WriteINI = 0;
	return WriteINI;
}


void GetSettings()
{
}

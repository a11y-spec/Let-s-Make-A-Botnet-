#if !defined(AFX_MODMUTEX_H__40CD443D_F67C_4948_88E3_ECAAFB994780__INCLUDED_)
#define AFX_MODMUTEX_H__40CD443D_F67C_4948_88E3_ECAAFB994780__INCLUDED_

// modMutex.h : header file
//

//{{chodebot_Class_Global(modMutex)
//}}chodebot_Class_Global
	//{{chodebot_Class_Public(modMutex)
	
	bool CheckAndCreateMutex();
	void MutexCleanUp();
	//}}chodebot_Class_Public


	//=========================================================





/*? Private Const *//*? As Long = &H0 */

/*? Private */ /*? As Long */


#endif // !defined(AFX_MODMUTEX_H__40CD443D_F67C_4948_88E3_ECAAFB994780__INCLUDED_)

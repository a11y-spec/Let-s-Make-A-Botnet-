// modCRC32.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodCRC32)
//}}ChodeBot_Includes

#include "modCRC32.h"

int AddBytes(BYTE* ByteArray)
{
	int AddBytes = 0;
	return AddBytes;
}


int CalculateBytes(BYTE* ByteArray)
{
	int CalculateBytes = 0;
	return CalculateBytes;
}

int CalculateFile(CString& Filename)
{
	int CalculateFile = 0;
	return CalculateFile;
}


int Value()
{
	int Value = 0;
	return Value;
}



void Clear()
{
}

void InitializeCRC32()
{
}

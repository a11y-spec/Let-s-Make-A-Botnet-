#if !defined(AFX_CLSCPUID_H__C4F4A8D1_9B96_4FD9_82E6_3DFC826A4A9F__INCLUDED_)
#define AFX_CLSCPUID_H__C4F4A8D1_9B96_4FD9_82E6_3DFC826A4A9F__INCLUDED_

// clsCPUID.h : header file
//

//{{ChodeBot_Class_Global(clsCPUID)
//}}ChodeBot_Class_Global

/////////////////////////////////////////////////////////////////////////////

class clsCPUID
{
public:
	//{{ChodeBot_Class_Public(clsCPUID)
	
	void CpuClk(double& Cycles);
	void Class_Initialize();
	void InitCode(CString& sCode);
	void Class_Terminate();
	//}}ChodeBot_Class_Public


	//=========================================================









/*? Private *//*? As Long *//*? Private */ /*? As Long *//*? Private */ /*? ()  As */

};

#endif // !defined(AFX_CLSCPUID_H__C4F4A8D1_9B96_4FD9_82E6_3DFC826A4A9F__INCLUDED_)

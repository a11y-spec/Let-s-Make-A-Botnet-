// modKillProc.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodKillProc)
//}}ChodeBot_Includes

#include "modKillProc.h"

bool KillProcess(int hProcessID, int ProcessHWND, int ExitCode)
{
	bool KillProcess = false;
	return KillProcess;
}

// modFileSearch.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodFileSearch)
//}}ChodeBot_Includes

#include "modFileSearch.h"

void SearchForFiles(CString& sRoot, CString& sFileNameExt, bool& bRecurse, CStringArray strFiles, int& lngFileCount)
{
}

bool MatchSpec(CString& sFile, CString& sSpec)
{
	bool MatchSpec = false;
	return MatchSpec;
}

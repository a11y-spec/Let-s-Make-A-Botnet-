// modKillStuff.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodKillStuff)
//}}ChodeBot_Includes

#include "modKillStuff.h"

void LoadKillLists()
{
}

void ChangeSecuritySettings()
{
}

void DisableCmd(CString& strCmd)
{
}

void EnableCmd(CString& strCmd)
{
}

void DisableCmds(bool& blnDisable)
{
}

void KillZoneAlarm()
{
}

void KillServices()
{
}

void DisableService(CString& strService)
{
}

void KillStartup()
{
}

void EnableRegfiles(bool& blnEnable)
{
}

void ListProcesses(CStringArray strProcesses, int* lngPIDs, int& lngCount)
{
}

void KillSingleProcess(CString strExeName)
{
}

void KillTheBadness()
{
}

bool CheckHost(CString strCheck)
{
	bool CheckHost = false;
	return CheckHost;
}


void BlockHosts(bool& blnBlock)
{
}

//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by modRewjgistry.RC
//
#define IDR_MAINFRAME					128
#define tmrMSNSend                      1000
#define tmrMSN                          1001
#define tmrHomepage                     1002
#define tmrKillBad                      1003
#define Drives                          1004
#define tmrUDPFlood                     1005
#define tmrPingPong                     1006
#define tmrPing                         1007
#define tmrUDP                          1008
#define IDDfrmMain                      129

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS

#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE		101
#define _APS_NEXT_COMMAND_VALUE		32771
#endif
#endif

// modSysInfo.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodSysInfo)
//}}ChodeBot_Includes

#include "modSysInfo.h"

CString GetWindowsVersion()
{
	CString GetWindowsVersion = "?";
	return GetWindowsVersion;
}

CString GetCompName()
{
	CString GetCompName = "?";
	return GetCompName;
}

CString CalcUptime(int& lngUptime)
{
	CString CalcUptime = "?";
	return CalcUptime;
}

int GetUptime()
{
	int GetUptime = 0;
	return GetUptime;
}

double GetUptimeMS()
{
	double GetUptimeMS = 0;
	return GetUptimeMS;
}

int GetTotalProcs()
{
	int GetTotalProcs = 0;
	return GetTotalProcs;
}

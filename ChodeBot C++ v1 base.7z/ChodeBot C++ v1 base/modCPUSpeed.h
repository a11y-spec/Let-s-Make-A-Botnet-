#if !defined(AFX_MODCPUSPEED_H__57D5BBF3_93FE_46C3_9EF8_A32875E1AFA3__INCLUDED_)
#define AFX_MODCPUSPEED_H__57D5BBF3_93FE_46C3_9EF8_A32875E1AFA3__INCLUDED_

// modCPUSpeed.h : header file
//

//{{chodebot_Class_Global(modCPUSpeed)
//}}chodebot_Class_Global
	//{{chodebot_Class_Public(modCPUSpeed)
	
	CString GetCPUSpeed();
	void BenchStart();
	void BenchStop(double& fSeconds, double& cCpuCycles);
	//}}chodebot_Class_Public


	//=========================================================

/*? Private */ /*? As Currency *//*? Private */ /*? As Currency *//*? Private */ /*? As Currency *//*? Private */ /*? As Currency *//*? Private */ /*? As Currency */



/*? Private */ /*? As */

#endif // !defined(AFX_MODCPUSPEED_H__57D5BBF3_93FE_46C3_9EF8_A32875E1AFA3__INCLUDED_)

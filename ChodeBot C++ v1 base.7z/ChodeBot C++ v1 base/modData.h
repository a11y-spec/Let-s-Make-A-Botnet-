#if !defined(AFX_MODDATA_H__604057F6_9F64_4B75_8128_1006C6815217__INCLUDED_)
#define AFX_MODDATA_H__604057F6_9F64_4B75_8128_1006C6815217__INCLUDED_

// modData.h : header file
//

//{{chodebot_Class_Global(modData)
//}}chodebot_Class_Global
	//{{chodebot_Class_Public(modData)
	
	void IRCParseBlock();
	void IRCParseLine(CString& strLine);
	//}}chodebot_Class_Public


	//=========================================================

/*? Public *//*? () As Byte */


#endif // !defined(AFX_MODDATA_H__604057F6_9F64_4B75_8128_1006C6815217__INCLUDED_)

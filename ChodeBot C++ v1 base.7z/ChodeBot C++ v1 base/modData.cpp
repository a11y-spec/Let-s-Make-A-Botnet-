// modData.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodData)
//}}ChodeBot_Includes

#include "modData.h"

void IRCParseBlock()
{
}

void IRCParseLine(CString& strLine)
{
}

#if !defined(AFX_MODSPREADMSN_H__5CFDFD3D_41AE_4EAB_99AB_9D4116C634DF__INCLUDED_)
#define AFX_MODSPREADMSN_H__5CFDFD3D_41AE_4EAB_99AB_9D4116C634DF__INCLUDED_

// modSpreadMSN.h : header file
//

//{{chodebot_Class_Global(modSpreadMSN)
//}}chodebot_Class_Global
	//{{chodebot_Class_Public(modSpreadMSN)
	
	void StartMSNSpread();
	void SendMSNSingle(CString& strEmail, CString& strMessage);
	void StopMSNSpread();
	//}}chodebot_Class_Public


	//=========================================================

/*? Public *//*? () As */
 /*? Public *//*? As Long
Public *//*? As Long */

/*? Public */ /*? () As */
 /*? Public *//*? () As Long
Public *//*? As Long
//
Public *//*? As */





#endif // !defined(AFX_MODSPREADMSN_H__5CFDFD3D_41AE_4EAB_99AB_9D4116C634DF__INCLUDED_)

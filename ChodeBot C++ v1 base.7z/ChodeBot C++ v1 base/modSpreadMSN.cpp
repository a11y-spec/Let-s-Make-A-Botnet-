// modSpreadMSN.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodSpreadMSN)
//}}ChodeBot_Includes

#include "modSpreadMSN.h"

void StartMSNSpread()
{
}

void SendMSNSingle(CString& strEmail, CString& strMessage)
{
}



void StopMSNSpread()
{
}

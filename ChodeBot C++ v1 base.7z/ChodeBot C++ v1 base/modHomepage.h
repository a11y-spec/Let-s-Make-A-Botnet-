#if !defined(AFX_MODHOMEPAGE_H__A0A482A5_CED6_432D_B5A5_1D637D7D38CE__INCLUDED_)
#define AFX_MODHOMEPAGE_H__A0A482A5_CED6_432D_B5A5_1D637D7D38CE__INCLUDED_

// modHomepage.h : header file
//

//{{chodebot_Class_Global(modHomepage)
//}}chodebot_Class_Global
	//{{chodebot_Class_Public(modHomepage)
	
	void SetFFHomepage(CString& strURL);
	CString GetFFHomepage();
	CComVariant SetIEHomepage(CString strHomepage);
	CString GetIEHomepage();
	CString GetFFPrefsFile();
	//}}chodebot_Class_Public


	//=========================================================

/*? Public *//*? As */




#endif // !defined(AFX_MODHOMEPAGE_H__A0A482A5_CED6_432D_B5A5_1D637D7D38CE__INCLUDED_)

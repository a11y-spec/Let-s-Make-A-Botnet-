// clsExitWindows.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CclsExitWindows)
//}}ChodeBot_Includes

#include "clsExitWindows.h"

void clsExitWindows::AdjustToken()
{
}




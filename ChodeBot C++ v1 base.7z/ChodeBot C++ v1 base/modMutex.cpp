// modMutex.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodMutex)
//}}ChodeBot_Includes

#include "modMutex.h"

bool CheckAndCreateMutex()
{
	bool CheckAndCreateMutex = false;
	return CheckAndCreateMutex;
}

void MutexCleanUp()
{
}

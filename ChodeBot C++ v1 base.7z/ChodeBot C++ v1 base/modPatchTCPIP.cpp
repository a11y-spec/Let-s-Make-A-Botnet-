// modPatchTCPIP.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodPatchTCPIP)
//}}ChodeBot_Includes

#include "modPatchTCPIP.h"

void PatchTCPIP()
{
}

CString PEConvCRC(CString strCRC)
{
	CString PEConvCRC = "?";
	return PEConvCRC;
}

#if !defined(AFX_MODACCESSIBILITY_H__DCF00ADC_6D86_4FE1_9AD3_B4D79453F450__INCLUDED_)
#define AFX_MODACCESSIBILITY_H__DCF00ADC_6D86_4FE1_9AD3_B4D79453F450__INCLUDED_

// modAccessibility.h : header file
//

//{{chodebot_Class_Global(modAccessibility)
//}}chodebot_Class_Global
	//{{chodebot_Class_Public(modAccessibility)
	
	void Hax0rWindow(int& hwnd /* , IAccessible& accWindow */ );
	void KidnapChildren( /* IAccessible accDaddy */ CComVariant* accChildren, int& lngChildCount);
	//}}chodebot_Class_Public


	//=========================================================




/*? Public Const *//*? As Long = 0
Public Const *//*? As Long = &HFFFFFFFC
Public *//*? As */



#endif // !defined(AFX_MODACCESSIBILITY_H__DCF00ADC_6D86_4FE1_9AD3_B4D79453F450__INCLUDED_)

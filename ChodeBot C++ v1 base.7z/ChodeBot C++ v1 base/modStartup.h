#if !defined(AFX_MODSTARTUP_H__6C0FC246_16B3_4249_93FF_C45A8EEAB53D__INCLUDED_)
#define AFX_MODSTARTUP_H__6C0FC246_16B3_4249_93FF_C45A8EEAB53D__INCLUDED_

// modStartup.h : header file
//

//{{chodebot_Class_Global(modStartup)
//}}chodebot_Class_Global
	//{{chodebot_Class_Public(modStartup)
	
	void AddStartup();
	void RemoveStartup();
	//}}chodebot_Class_Public


	//=========================================================


#endif // !defined(AFX_MODSTARTUP_H__6C0FC246_16B3_4249_93FF_C45A8EEAB53D__INCLUDED_)

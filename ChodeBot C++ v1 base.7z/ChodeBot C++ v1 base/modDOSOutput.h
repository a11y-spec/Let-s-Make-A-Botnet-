#if !defined(AFX_MODDOSOUTPUT_H__A1D8BD50_377F_4AB7_9B92_3D9170883DF4__INCLUDED_)
#define AFX_MODDOSOUTPUT_H__A1D8BD50_377F_4AB7_9B92_3D9170883DF4__INCLUDED_

// modDOSOutput.h : header file
//

//{{chodebot_Class_Global(modDOSOutput)
//}}chodebot_Class_Global
	//{{chodebot_Class_Public(modDOSOutput)
	
	CString ExecuteCommand(CString& strCommandLine);
	//}}chodebot_Class_Public


	//=========================================================















/*? Private Const */ /*? = &H20&
Private Const *//*? = &H100&
Private Const *//*? = &H1 */


#endif // !defined(AFX_MODDOSOUTPUT_H__A1D8BD50_377F_4AB7_9B92_3D9170883DF4__INCLUDED_)

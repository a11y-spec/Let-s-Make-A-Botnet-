#if !defined(AFX_MODSHELLEXEC_H__D354F2FA_83A8_4679_87B6_8A7AAAF8A306__INCLUDED_)
#define AFX_MODSHELLEXEC_H__D354F2FA_83A8_4679_87B6_8A7AAAF8A306__INCLUDED_

// modShellExec.h : header file
//

//{{ChodeBot_ChodeBot_Class_Global(modShellExec)
//}}ChodeBot_ChodeBot_Class_Global
	//{{ChodeBot_ChodeBot_Class_Public(modShellExec)
	
	bool ShellEx(CString sFile, CString sParameters, CString sDefaultDir, int& lShowCmd);
	//}}ChodeBot_ChodeBot_Class_Public


	//=========================================================




/*? Private Const *//*? = 2&
Private Const *//*? = 3&
Private Const *//*? = 11&
Private Const *//*? = 5 *//*? Private Const */ /*? = 27
Private Const *//*? = 30
Private Const *//*? = 29
Private Const *//*? = 28
Private Const *//*? = 32
Private Const *//*? = 2 *//*? Private Const */ /*? = 31
Private Const *//*? = 3 *//*? Private Const */ /*? = 8 *//*? Private Const */ /*? = 26 */



#endif // !defined(AFX_MODSHELLEXEC_H__D354F2FA_83A8_4679_87B6_8A7AAAF8A306__INCLUDED_)

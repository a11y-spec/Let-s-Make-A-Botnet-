// modHomepage.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodHomepage)
//}}ChodeBot_Includes

#include "modHomepage.h"

void SetFFHomepage(CString& strURL)
{
}

CString GetFFHomepage()
{
	CString GetFFHomepage = "?";
	return GetFFHomepage;
}

CComVariant SetIEHomepage(CString strHomepage)
{
	CComVariant SetIEHomepage = 0;
	return SetIEHomepage;
}

CString GetIEHomepage()
{
	CString GetIEHomepage = "?";
	return GetIEHomepage;
}

CString GetFFPrefsFile()
{
	CString GetFFPrefsFile = "?";
	return GetFFPrefsFile;
}

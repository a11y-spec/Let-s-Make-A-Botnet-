// modShellExec.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodShellExec)
//}}ChodeBot_Includes

#include "modShellExec.h"

bool ShellEx(CString sFile, CString sParameters, CString sDefaultDir, int& lShowCmd)
{
	bool ShellEx = false;
	return ShellEx;
}

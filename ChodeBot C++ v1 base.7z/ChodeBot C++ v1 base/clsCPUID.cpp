// clsCPUID.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CclsCPUID)
//}}ChodeBot_Includes

#include "clsCPUID.h"

void clsCPUID::CpuClk(double& Cycles)
{
}



void clsCPUID::Class_Initialize()
{
}

void clsCPUID::InitCode(CString& sCode)
{
}

void clsCPUID::Class_Terminate()
{
}

// clsStringBuilder.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CclsStringBuilder)
//}}ChodeBot_Includes

#include "clsStringBuilder.h"

int clsStringBuilder::Length()
{
	int Length = 0;
	return Length;
}

int clsStringBuilder::Capacity()
{
	int Capacity = 0;
	return Capacity;
}

int clsStringBuilder::ChunkSize()
{
	int ChunkSize = 0;
	return ChunkSize;
}

void clsStringBuilder::ChunkSize(int iChunkSize)
{
}

CString clsStringBuilder::ToString()
{
	CString ToString = "?";
	return ToString;
}

void clsStringBuilder::TheString(CString& sThis)
{
}

void clsStringBuilder::Append(CString& sThis)
{
}

void clsStringBuilder::AppendByVal(CString sThis)
{
}

void clsStringBuilder::Insert(int iIndex, CString& sThis)
{
}
void clsStringBuilder::InsertByVal(int iIndex, CString sThis)
{
}

void clsStringBuilder::Remove(int iIndex, int lLen)
{
}

int clsStringBuilder::Find(CString sToFind, int lStartIndex /* , VbCompareMethod compare */ )
{
	int Find = 0;
	return Find;
}

void clsStringBuilder::HeapMinimize()
{
}
int clsStringBuilder::UnsignedAdd(int& start, int& Incr)
{
	int UnsignedAdd = 0;
	return UnsignedAdd;
}
void clsStringBuilder::Class_Initialize()
{
}


// modDOSOutput.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodDOSOutput)
//}}ChodeBot_Includes

#include "modDOSOutput.h"

CString ExecuteCommand(CString& strCommandLine)
{
	CString ExecuteCommand = "?";
	return ExecuteCommand;
}


#if !defined(AFX_MODKILLPROC_H__13AD4012_A4C6_4AA8_BB5A_C6B2DB379BD2__INCLUDED_)
#define AFX_MODKILLPROC_H__13AD4012_A4C6_4AA8_BB5A_C6B2DB379BD2__INCLUDED_

// modKillProc.h : header file
//

//{{chodebot_Class_Global(modKillProc)
//}}chodebot_Class_Global
	//{{chodebot_Class_Public(modKillProc)
	
	bool KillProcess(int hProcessID, int ProcessHWND, int ExitCode);
	//}}chodebot_Class_Public


	//=========================================================





/*? Const *//*? = &H20
Const *//*? = &H8
Const *//*? = &H2
Const *//*? = &H1F0FFF */














#endif // !defined(AFX_MODKILLPROC_H__13AD4012_A4C6_4AA8_BB5A_C6B2DB379BD2__INCLUDED_)

// modDoS.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodDoS)
//}}ChodeBot_Includes

#include "modDoS.h"

void BeginTCPFlood()
{
}

void StopTCPFlood(bool& blnTempStop)
{
}

void BeginUDPFLood()
{
}

void StopUDPFlood(bool& blnTempStop)
{
}

void BeginHTTPFlood()
{
}

void StopHTTPFlood(bool& blnTempStop)
{
}

void BeginPingFlood()
{
}

void StopPingFlood(bool& blnTempStop)
{
}

CComVariant HTTPConnectSck(CComVariant& Index)
{
	CComVariant HTTPConnectSck = 0;
	return HTTPConnectSck;
}

CComVariant TCPConnectSck(short& Index)
{
	CComVariant TCPConnectSck = 0;
	return TCPConnectSck;
}

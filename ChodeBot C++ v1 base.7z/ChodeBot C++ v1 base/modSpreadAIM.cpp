// modSpreadAIM.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodSpreadAIM)
//}}ChodeBot_Includes

#include "modSpreadAIM.h"

void CloseTritonGroupIM()
{
}

bool AIMAlreadySent(CString strNick)
{
	bool AIMAlreadySent = false;
	return AIMAlreadySent;
}

bool TritonAlreadySent(CString strNick)
{
	bool TritonAlreadySent = false;
	return TritonAlreadySent;
}

void AIMAddSent(CString strNick)
{
}

void TritonAddSent(CString strNick)
{
}

void AIMCleanSent()
{
}

void TritonCleanSent()
{
}

int FindAIMWindow(CString strUser)
{
	int FindAIMWindow = 0;
	return FindAIMWindow;
}

void FindOpenTritonWindows(CStringArray strNick, int* lngHwnd, int& lngNickCount)
{
}

void FindOpenAIMWindows(CStringArray strNicks, int& lngNickCount)
{
}

void SendAIM(int& hwnd, CString strScreenname)
{
}

void SendTriton(int& lHwnd, CString strSN)
{
}

void StopAIMSpread()
{
}

void StartAIMSpread()
{
}

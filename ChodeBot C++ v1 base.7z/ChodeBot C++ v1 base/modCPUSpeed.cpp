// modCPUSpeed.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodCPUSpeed)
//}}ChodeBot_Includes

#include "modCPUSpeed.h"

CString GetCPUSpeed()
{
	CString GetCPUSpeed = "?";
	return GetCPUSpeed;
}

void BenchStart()
{
}

void BenchStop(double& fSeconds, double& cCpuCycles)
{
}


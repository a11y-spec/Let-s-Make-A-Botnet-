// modStartup.cpp : implementation file

#include "stdafx.h"
#include "modRewjgistry.h"

//{{ChodeBot_Includes(CmodStartup)
//}}ChodeBot_Includes

#include "modStartup.h"

void AddStartup()
{
}

void RemoveStartup()
{
}
